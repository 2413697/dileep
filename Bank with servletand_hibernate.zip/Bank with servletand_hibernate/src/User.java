import java.io.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/User")
public class User extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name=request.getParameter("t1");
		String password=request.getParameter("t2");
		String address=request.getParameter("t3");
		String phoneno=request.getParameter("t4");
		String email=request.getParameter("t5");

		String button=request.getParameter("btn");
		

		try {
			User1 user=new User1();
			user.setAddress(address);
			user.setEmail(email);
			user.setName(name);
			user.setPassword(password);
			user.setPhoneno(phoneno);
			DAO dao=new DAO();
			dao.saveUser(user);
			
			response.sendRedirect("Home.html");

		}catch(Exception ae){
			ae.printStackTrace();
		}
	}

}

