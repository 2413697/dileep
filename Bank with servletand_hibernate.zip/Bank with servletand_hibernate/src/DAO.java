import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class DAO {
	public void saveUser(User1 dto)
	{
		Session session=null;
		Transaction transaction=null;
		SessionFactory factory=HibernateUtil.getSessionFactory();
		try {
			 session= factory.openSession();
			 transaction= session.beginTransaction();
			 session.save(dto);
			 transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}
		finally
		{
			if(session!=null)
			session.close();
			
		}}
}
